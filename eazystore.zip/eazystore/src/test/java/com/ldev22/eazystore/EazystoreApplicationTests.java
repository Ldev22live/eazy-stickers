package com.ldev22.eazystore;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EazystoreApplicationTests {

	@Test
	void contextLoads() {
	}

}
